from flask_app import app 
from flask import render_template, request

@app.route('/')
def home():
    return render_template("git.html")

