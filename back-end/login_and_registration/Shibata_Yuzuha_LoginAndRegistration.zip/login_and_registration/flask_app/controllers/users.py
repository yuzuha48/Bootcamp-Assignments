from flask_app import app 
from flask_app.models import user
from flask import render_template, redirect, request, session, flash
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/')
def home_page():
    return render_template("login_and_registration.html")

@app.route('/register', methods=['POST'])
def register():
    if not user.User.validate_user(request.form):
        session["first_name"] = request.form["first_name"]
        session["last_name"] = request.form["last_name"]
        session["email"] = request.form["email"]
        return redirect('/')

    user_info = user.User.save(request.form)
    session["user_id"] = user_info.id
    session["first_name"] = user_info.first_name
    session["last_name"] = user_info.last_name
    session["email"] = user_info.email
    return redirect('/welcome')

@app.route('/welcome')
def welcome():
    if 'user_id' not in session:
        return redirect('/log_out')
    user_info = user.User.get_one(session['user_id'])
    return render_template("welcome.html", user=user_info)

@app.route('/login', methods=['POST'])
def login():
    user_in_db = user.User.get_by_email(request.form)
    if not user_in_db:
        session["login_email"] = request.form["email"]
        flash("Invalid Email.", "login")
        return redirect('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        session["login_email"] = request.form["email"]
        flash("Invalid Password.", "login")
        return redirect('/')
    session['user_id'] = user_in_db.id
    return redirect('/welcome')

@app.route('/log_out')
def log_out():
    session.clear()
    return redirect('/')
